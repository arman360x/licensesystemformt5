<?php
session_start();

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Pagination setup
$records_per_page = 25;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $records_per_page;

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Get total number of records with search
$total_sql = "SELECT COUNT(*) FROM licenses WHERE name LIKE :search OR email LIKE :search OR account_number LIKE :search OR broker_name LIKE :search OR license_key LIKE :search OR promo_code LIKE :search OR expire_date LIKE :search OR phone LIKE :search OR description LIKE :search";
$total_stmt = $pdo->prepare($total_sql);
$total_stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
$total_stmt->execute();
$total_records = $total_stmt->fetchColumn();
$total_pages = ceil($total_records / $records_per_page);

// Fetch records for the current page with search
$sql = "SELECT * FROM licenses WHERE name LIKE :search OR email LIKE :search OR account_number LIKE :search OR broker_name LIKE :search OR license_key LIKE :search OR promo_code LIKE :search OR expire_date LIKE :search OR phone LIKE :search OR description LIKE :search LIMIT :start, :limit";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
$stmt->bindValue(':start', $start, PDO::PARAM_INT);
$stmt->bindValue(':limit', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle email sending
if (isset($_GET['send_email']) && isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    
    // Fetch user details
    $user_sql = "SELECT * FROM licenses WHERE id = :id";
    $user_stmt = $pdo->prepare($user_sql);
    $user_stmt->bindValue(':id', $userId, PDO::PARAM_INT);
    $user_stmt->execute();
    $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $to = $user['email'];
        $subject = 'Important Information';
        $message = "Hello {$user['name']},\n\nThis is a predefined message.\n\nRegards,\nYour Company";
        $headers = 'From: your-email@example.com' . "\r\n" .
                   'Reply-To: your-email@example.com' . "\r\n" .
                   'X-Mailer: PHP/' . phpversion();
        
        mail($to, $subject, $message, $headers);
        
        header("Location: dashboard.php?page=$page&search=" . urlencode($search));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
        }
        .search-form {
            display: flex;
            align-items: center;
        }
        .search-form input {
            padding: 8px;
            border: none;
            border-radius: 4px 0 0 4px;
            font-size: 16px;
            width: 200px;
        }
        .search-form button {
            padding: 8px 16px;
            border: none;
            border-radius: 0 4px 4px 0;
            background-color: #0056b3;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        .search-form button:hover {
            background-color: #003d80;
        }
        .main-container {
            display: flex;
            flex: 1;
        }
        .sidebar {
            width: 200px;
            background-color: #343a40;
            color: #fff;
            padding: 15px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .button-group a {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            text-decoration: none;
            color: #fff;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .button-group .btn-primary {
            background-color: #007bff;
        }
        .button-group .btn-primary:hover {
            background-color: #0056b3;
        }
        .button-group .btn-secondary {
            background-color: #6c757d;
        }
        .button-group .btn-secondary:hover {
            background-color: #5a6268;
        }
        .button-group .btn-logout {
            background-color: #dc3545;
        }
        .button-group .btn-logout:hover {
            background-color: #c82333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            
             padding: 12px; /* Increase padding to add more height */
        vertical-align: middle; /* Ensure text and buttons are vertically aligned */
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .pagination {
            margin-top: 20px;
            text-align: center;
        }
        .pagination a {
            display: inline-block;
            padding: 8px 16px;
            margin: 0 2px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #007bff;
            font-size: 14px;
        }
        .pagination a.active {
            background-color: #007bff;
            color: #fff;
            border: 1px solid #007bff;
        }
        .pagination a:hover {
            background-color: #ddd;
        }
        
        
        .actions {
        width: 100px; /* Increase width of the actions column */
        white-space: nowrap; /* Prevent wrapping of buttons */
    }
        
        .actions a {
        text-decoration: none; /* Remove underline */
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 14px;
        margin-right: 5px;
        color: #fff;
        display: inline-block;
        
    }

    .actions a.edit {
        background-color: #007bff; /* Blue for edit */
    }

    .actions a.toggle {
        background-color: #28a745; /* Green for enable/disable */
    }

    .actions a.delete {
        background-color: #dc3545; /* Red for delete */
    }

    .actions a.email {
        background-color: #17a2b8; /* Cyan for send email */
    }

    .actions a:hover {
        opacity: 0.8; /* Add a hover effect */
    }
        
        
        
    </style>
</head>
<body>
    <div class="header">
        <h1>License Dashboard</h1>
        <form action="dashboard.php" method="get" class="search-form">
            <input type="text" name="search" placeholder="Search by name, email, or any field" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">Search</button>
        </form>
    </div>
    <div class="main-container">
        <div class="content">
            <div class="container">
<!--                <h1>User Records</h1>-->
                <div class="button-group">
                    <a href="add_user.html" class="btn-primary">Add User</a>
                    <a href="add_admin.html" class="btn-secondary">Add Admin</a>
                    <a href="logout.php" class="btn-logout">Logout</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Account Number</th>
                            <th>Broker Name</th>
                            <th>License Key</th>
                            <th>Promo Code</th>
                            <th>Expire Date</th>
                            <th>Phone</th>
                            <th>Description</th>
                            <th>License Status</th> <!-- New column for enabled/disabled -->
                            <th>Actions</th>
                            <th>Send Email</th> <!-- New column for Send Email -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records): ?>
                            <?php foreach ($records as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['id']); ?></td>
                                <td><?php echo htmlspecialchars($record['name']); ?></td>
                                <td><?php echo htmlspecialchars($record['email']); ?></td>
                                <td><?php echo htmlspecialchars($record['account_number']); ?></td>
                                <td><?php echo htmlspecialchars($record['broker_name']); ?></td>
                                <td><?php echo htmlspecialchars($record['license_key']); ?></td>
                                <td><?php echo htmlspecialchars($record['promo_code']); ?></td>
                                <td><?php echo htmlspecialchars($record['expire_date']); ?></td>
                                <td><?php echo htmlspecialchars($record['phone']); ?></td>
                                <td><?php echo htmlspecialchars($record['description']); ?></td>
                                <!--<td><?php echo $record['is_enabled'] ? 'Enabled' : 'Disabled'; ?></td> <!-- New column -->
                                
                                <td class="license-status">
                <a href="toggle_license.php?id=<?php echo htmlspecialchars($record['id']); ?>" class="toggle">
                    <?php echo $record['is_enabled'] ? 'Disable' : 'Enable'; ?>
                </a>
            </td>
                                
                                
                                <td class="actions">
                                    
                                   
         
    <a href="edit_user.php?id=<?php echo htmlspecialchars($record['id']); ?>" class="edit">Edit</a>
   
    <a href="delete_user.php?id=<?php echo htmlspecialchars($record['id']); ?>" class="delete" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
</td>

<td>
                                    <a href="send_email_form.php?id=<?php echo htmlspecialchars($record['id']); ?>" class="email">Send Email</a>
                                </td>
                                
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11">No records found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                    <a href="dashboard.php?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">&laquo; Previous</a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="dashboard.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                    <a href="dashboard.php?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Next &raquo;</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
