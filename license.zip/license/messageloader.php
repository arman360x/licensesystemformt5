<?php
// Set the content type to application/json
header('Content-Type: application/json');

// Function to generate a random 60-character string
function generateRandomString($length = 86) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Initialize an empty array for 50 key-value pairs
    $data = [];

    // Loop to add 50 key-value pairs where values are 60 characters long
    for ($i = 1; $i <= 100; $i++) {
        $data["key$i"] = generateRandomString();
    }

    // Send the array as a JSON response
    echo json_encode($data);
} else {
    // If it's not a GET request, send a 405 Method Not Allowed response
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}
?>
