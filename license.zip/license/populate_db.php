<?php
// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Function to generate random strings
function generateRandomString($length = 10) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Function to generate a random date
function generateRandomDate() {
    $start = strtotime('2024-01-01');
    $end = strtotime('2024-12-31');
    $randomDate = date('Y-m-d', mt_rand($start, $end));
    return $randomDate;
}

// Prepare SQL statement
$sql = "INSERT INTO licenses (name, email, account_number, broker_name, license_key, promo_code, expire_date, phone, description) 
        VALUES (:name, :email, :account_number, :broker_name, :license_key, :promo_code, :expire_date, :phone, :description)";
$stmt = $pdo->prepare($sql);

// Insert 100 records
for ($i = 1; $i <= 100; $i++) {
    $name = 'User' . $i;
    $email = 'user' . $i . '@example.com';
    $account_number = generateRandomString(10);
    $broker_name = 'Broker' . rand(1, 10);
    $license_key = generateRandomString(16);
    $promo_code = generateRandomString(8);
    $expire_date = generateRandomDate();
    $phone = '+1' . rand(1000000000, 9999999999);
    $description = 'Description for user ' . $i;

    // Bind parameters and execute the statement
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':account_number' => $account_number,
        ':broker_name' => $broker_name,
        ':license_key' => $license_key,
        ':promo_code' => $promo_code,
        ':expire_date' => $expire_date,
        ':phone' => $phone,
        ':description' => $description
    ]);
}

echo "100 records inserted successfully.";
?>
