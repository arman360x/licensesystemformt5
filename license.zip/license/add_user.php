<?php
session_start();

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if form data is posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $account_number = trim($_POST['account_number']);
    $broker_name = trim($_POST['broker_name']);
    $license_key = trim($_POST['license_key']);
    $promo_code = trim($_POST['promo_code']);
    $expire_date = $_POST['expire_date'];
    $phone = trim($_POST['phone']);
    $description = trim($_POST['description']);

    // Validate and sanitize input
    if (!empty($name) && !empty($email) && !empty($account_number) && !empty($broker_name) && !empty($license_key) && !empty($expire_date)) {
        // Prepare the SQL statement
        $sql = "INSERT INTO licenses (name, email, account_number, broker_name, license_key, promo_code, expire_date, phone, description) 
                VALUES (:name, :email, :account_number, :broker_name, :license_key, :promo_code, :expire_date, :phone, :description)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        try {
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':account_number' => $account_number,
                ':broker_name' => $broker_name,
                ':license_key' => $license_key,
                ':promo_code' => $promo_code,
                ':expire_date' => $expire_date,
                ':phone' => $phone,
                ':description' => $description
            ]);

            // Redirect to success page
            header("Location: success2.html");
            exit();
        } catch (PDOException $e) {
            die("Error adding user: " . $e->getMessage());
        }
    } else {
        echo "Please fill all required fields.";
    }
} else {
    echo "Invalid request.";
}
?>
