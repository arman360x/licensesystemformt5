<?php
// Database connection parameters
return [
    'host' => 'localhost',
    'dbname' => 'martretlicense',
    'user' => 'martretuser', // replace with your MySQL username
    'pass' => '@martretuser' // replace with your MySQL password
];
?>
