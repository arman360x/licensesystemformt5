<?php
session_start();

// Include the configuration file
$config = require 'config.php';

// Create a new PDO instance
try {
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']}",
        $config['user'],
        $config['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if 'id' parameter is set
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];

    // Prepare the SQL statement
    $sql = "DELETE FROM licenses WHERE id = :id";
    $stmt = $pdo->prepare($sql);

    // Bind parameters and execute the statement
    try {
        $stmt->execute([':id' => $id]);
        
        // Redirect to dashboard with a success message
        header("Location: dashboard.php?status=deleted");
        exit();
    } catch (PDOException $e) {
        die("Error deleting user: " . $e->getMessage());
    }
} else {
    die("Invalid request.");
}
?>
